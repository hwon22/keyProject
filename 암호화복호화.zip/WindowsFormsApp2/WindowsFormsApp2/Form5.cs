﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form5 : Form
    {
        string keyis;
        string keypan4;
        string text1;
        string text2;
        


        public Form5()
        {

        }
        public Form5(string encryptionPlain, string keypan)
        {

            InitializeComponent(); 
            textBox2.Text = encryptionPlain;
            //암호문
            keyis = textBox2.Text.ToUpper();
            keypan4 = keypan;

            Decrypt de = new Decrypt();
            text1 = de.Text(keyis);
            text2 = de.Decryption(keypan4, text1);
        }


        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("원래의 평문은 " + text2+ " 입니다.", "변환완료",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            
            this.Hide();    //form 전환
            Form6 setform6 = new Form6(text2);
            setform6.Owner = this;
            setform6.ShowDialog();
            this.Close();
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }
    }
    class Decrypt
    {
        public string Text(string b)
        {
            string Textis = b.ToLower();
            string[] s = new string[] { " " };
            string[] plainResult = Textis.Split(s, StringSplitOptions.RemoveEmptyEntries);
            string plainsResult = String.Concat(plainResult);

            char[] plaining = plainsResult.ToCharArray(0, plainsResult.Length);
            List<char> list2 = new List<char>();


            for (int k = 0; k < plaining.Length; k += 2)
            {
                list2.Add(plaining[k]);
                if (k + 1 < plaining.Length)
                {
                    if (plaining[k] == plaining[k + 1])
                    {
                        list2.Add('x');
                    }
                    list2.Add(plaining[k + 1]);
                }
            }
            if (list2.Count % 2 != 0)
            { list2.Add('x'); }

            string plain = String.Concat(list2); //암호문의 소문자화, 중복과 맨끝자리에 x가 추가된다.

            return plain;
        }

        

        public string Decryption(string keypan, string plain)
        {
            char[,] keytable5x5 = new char[5, 5];
            char[] arr; int k = 0; 
            arr = keypan.ToCharArray(0, keypan.Length);
            int a1 = 0, a2 = 0, b1 = 0, b2 = 0;
            int i, j;
            //암호판 만들기
            for (i = 0; i < 5; i++)
            {
                for (j = 0; j < 5; j++)
                {
                    keytable5x5[i, j] = arr[k];
                    k++;
                }
            }

            //두글자씩 잘라서 위치 파악하기
            List<char> cryptogram = new List<char>(); //

            char[] ResultPlain = new char[plain.Length];
            string plaintext = plain;
            char[] arr2 = plaintext.ToCharArray(0, plaintext.Length);
            char[] tmpArr = new char[2];
            char[] temp = new char[2];

            for (i = 0; i < plaintext.Length; i += 2)
            {

                temp[0] = arr2[i];
                temp[1] = arr2[i + 1];
                cryptogram.Add(temp[0]);
                cryptogram.Add(temp[1]);

                for (int x = 0; x < 5; x++)
                {
                    for (int y = 0; y < 5; y++)
                    {
                        if (keytable5x5[x, y] == temp[0])
                        {
                            a1 = x;
                            b1 = y;
                        }
                        if (keytable5x5[x, y] == temp[1])
                        {
                            a2 = x;
                            b2 = y;
                        }
                    }
                }

                //위치따라 암호문 만들기+암호문 return
                if (a1 == a2) // 같은 행
                {
                    tmpArr[0] = keytable5x5[a1, (b1 + 4) % 5];
                    tmpArr[1] = keytable5x5[a2, (b2 + 4) % 5];
                }
                else if (b1 == b2) // 같은 열
                {
                    tmpArr[0] = keytable5x5[(a1 + 4) % 5, b1];
                    tmpArr[1] = keytable5x5[(a2 + 4) % 5, b2];
                }
                else // 행, 열 모두 다른경우
                {
                    tmpArr[0] = keytable5x5[a2, b1];
                    tmpArr[1] = keytable5x5[a1, b2];
                }
                ResultPlain[i] = tmpArr[0];
                ResultPlain[i + 1] = tmpArr[1];
            }
            int length = ResultPlain.Length;
            for(i=0; i<length; i += 2)
            {
                //x제거
                temp[0] = ResultPlain[i];
                temp[1] = ResultPlain[i + 1];
                if (temp[1] == 'x' && temp[0] == ResultPlain[i + 2])
                {
                    length--;
                    for(j=i+1; j<length; j++)
                    {
                        ResultPlain[j] = ResultPlain[j + 1];
                    }
                    ResultPlain[j] = '\0';
                    i--;
                }
                if (ResultPlain[i] == 'x')
                {
                    ResultPlain[length-1] = '\0';
                }
                if (ResultPlain[length-1] == 'x' && length % 2 == 0)
                {
                    ResultPlain[length-1] = '\0';
                }
            }

            string str = string.Concat(ResultPlain);
            return str;

        }
    }
}
